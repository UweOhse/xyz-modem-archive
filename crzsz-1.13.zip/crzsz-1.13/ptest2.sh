#a short test for csz and crz using a named pipe - no modem used.
#usage ptest2.sh SomeBigFileinAnotherDirectory
#
locfile=`basename $1`
mknod fifo p
./csz  <fifo $1 |./crz - >fifo
rm fifo
#echo locfile $locfile
ls -l $1 $locfile
if cmp  $1 $locfile
then
	echo "File compare successful"
else
	echo "File compare failed"
fi
rm -i $locfile
