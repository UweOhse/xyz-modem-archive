#a short test for csz and crz using a named pipe - no modem used.
rm -f /tmp/c?zlog
mknod fifo p
./csz -vvvv <fifo /etc/hosts |./crz -vvvv >fifo
rm fifo
less /tmp/c?zlog
ls -l hosts
