/* the release version number as printed by the programs */

#define VERSION "1.02"

